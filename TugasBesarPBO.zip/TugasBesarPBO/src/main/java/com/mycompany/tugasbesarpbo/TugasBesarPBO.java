/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.tugasbesarpbo;

/**
 *
 * @author ASUS
 */
public class TugasBesarPBO {

    public static void main(String[] args) {
        System.out.println("Hello World!");
    }
}
